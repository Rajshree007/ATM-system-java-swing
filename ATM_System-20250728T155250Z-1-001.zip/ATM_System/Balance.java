package Checkbalancepack;

import com.mysql.cj.jdbc.Driver;

import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.Scanner;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Balance {
    // Database credentials
	Connection cn;
	Statement stmt;
	ResultSet rs;
	
	JFrame f;
	FlowLayout fl;
	JLabel lb;
	JTextField tf;
	JButton b;
	
	JLabel jp1;
	JLabel jp2;
	JLabel jp3;

    public void check_balance() {
        try {
			
			f=new JFrame("Check Balance");
			f.setSize(600,800);
			fl=new FlowLayout();
			f.setLayout(fl);
			
			
            Class.forName("com.mysql.cj.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://localhost/practise","root","1234");
			stmt = cn.createStatement();
			
			lb=new JLabel("Enter your Id:");
			tf=new JTextField(5);
			b=new JButton("Check Balance");
			
			f.add(lb);
			f.add(tf);
			f.add(b);
			
			jp1=new JLabel("");
			f.add(jp1);
			jp2=new JLabel("");
			f.add(jp2);
			jp3=new JLabel("");
			f.add(jp3);
			
			Myclass m=new Myclass();
			b.addActionListener(m);
			
			f.setVisible(true);
			
            rs.close();
            stmt.close();
            cn.close();
        } catch (SQLException e) {
            System.out.println(e);
		}catch(NullPointerException e){
			System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);
        }

    }
	class Myclass implements ActionListener{
		public void actionPerformed(ActionEvent e){
			try{
				String accno=tf.getText();
				 // sql query
				String sql = "SELECT bal,name FROM Bank WHERE ano='" + accno + "'";
				rs = stmt.executeQuery(sql);

				// Process the result set
				if (rs.next()) {
					String name = rs.getString("name");
					jp1.setText("Hello dear " + name + "...");
					int balance=rs.getInt("bal");
					jp2.setText("Your Account balance is: " + balance);

				} else {
					jp3.setText("Account not found.");
				}
			}
			catch(Exception ex){}
		}
	}

}
