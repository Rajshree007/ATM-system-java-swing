package Depositepack;

import com.mysql.cj.jdbc.Driver;

import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.Scanner;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Deposite {
    Connection cn;
	Statement stmt;
	ResultSet rs;

	JFrame f;
	FlowLayout fl;
	JLabel l1;
	JTextField tf1;
	JButton b1;
	JLabel l2;
	JTextField tf2;
	
	JLabel jp1;
	JLabel jp2;
	JLabel jp3;
	JLabel jp4;
    public void deposite_amount() {

        try {
			f=new JFrame("Deposite Money");
			f.setSize(600,800);
			fl=new FlowLayout();
			f.setLayout(fl);
			
            Class.forName("com.mysql.cj.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://localhost/practise","root","1234");
			stmt = cn.createStatement();

            // Open a connection
            
			l1=new JLabel("Enter your account no:");
			tf1=new JTextField(5);
			l2=new JLabel("Enter amount you want to Deposite:");
			tf2=new JTextField(10);
			b1=new JButton("OK");
			
			f.add(l1);
			f.add(tf1);
			f.add(l2);
			f.add(tf2);
			f.add(b1);
            
			jp1=new JLabel("");
			f.add(jp1);
			jp2=new JLabel("");
			f.add(jp2);
			jp3=new JLabel("");
			f.add(jp3);
			jp4=new JLabel("");
			f.add(jp4);
			
			Myclass m1=new Myclass();
			b1.addActionListener(m1);
			
			f.setVisible(true);
			
            rs.close();
            stmt.close();
            cn.close();
        }catch (SQLException e) {
            System.out.println(e);
        }catch(NullPointerException e){
			System.out.println(e);
		}catch (Exception e) {
            System.out.println(e);
		}

    }
	class Myclass implements ActionListener{
		public void actionPerformed(ActionEvent e){
			try{
				String accno=tf1.getText();
				// sql query
				String sql = "SELECT * FROM Bank WHERE ano='" + accno + "'";
				rs = stmt.executeQuery(sql);

				// Process the result set
				if (rs.next()) {
					int balance1 = rs.getInt("bal");
					
					String bal_input=tf2.getText();
					int balance=Integer.parseInt(bal_input);
					if(balance>0){
						int updated_balance = balance1 + balance;

						String updateQuery = "UPDATE Bank SET bal = ? WHERE ano = ?";
						PreparedStatement updateStatement = cn.prepareStatement(updateQuery);
						updateStatement.setInt(1, updated_balance);
						updateStatement.setString(2, accno);
						int rowsUpdated = updateStatement.executeUpdate();

						if (rowsUpdated > 0) {
							jp1.setText("Your money has been Deposited Successfully...");

						} else {
							jp2.setText("No rows updated. Balance update failed.");
						}

					}
					else{
						jp4.setText("cannot deposite 0 or negative");
					}
				   
					
				} else {
					jp3.setText("Account not found.");
				}
			}
			catch(Exception ex){}
		}
	}

}
