import Checkbalancepack.Balance;
import Openaccountpack.Openaccount;
import Withdrawpack.Withdraw;
import Depositepack.Deposite;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
class MyBank {
	JFrame f;
	JButton b1;
	JButton b2;
	JButton b3;
	JButton b4;
	JLabel lp;
	FlowLayout fl;
	
	MyBank(){
		try{
				f=new JFrame("My Bank");
				f.setSize(600,800);
				
				fl=new FlowLayout();
				f.setLayout(fl);
				
				lp=new JLabel("Welcome to my bank:");
				
				b1=new JButton("open_account");
				b2=new JButton("check_balance");
				b3=new JButton("withdraw");
				b4=new JButton("deposite");
				
				f.add(lp);
				f.add(b1);
				f.add(b2);
				f.add(b3);
				f.add(b4);
				
				
				Myclass1 m1=new Myclass1();
				b1.addActionListener(m1);
				
				Myclass2 m2=new Myclass2();
				b2.addActionListener(m2);
				
				Myclass3 m3=new Myclass3();
				b3.addActionListener(m3);
				
				Myclass4 m4=new Myclass4();
				b4.addActionListener(m4);
				
				f.setVisible(true);

		}
		catch(Exception e){
		}
		
	}
	class Myclass1 implements ActionListener{
		public void actionPerformed(ActionEvent e){
			Openaccount o = new Openaccount();
			o.Open_account();
		}
	}
	
	class Myclass2 implements ActionListener{
		public void actionPerformed(ActionEvent e){
			Balance b = new Balance();
			b.check_balance();
		}
	}
	
	class Myclass3 implements ActionListener{
		public void actionPerformed(ActionEvent e){
			Withdraw w = new Withdraw();
			w.Withdraw_amount();
		}
	}
	
	class Myclass4 implements ActionListener{
		public void actionPerformed(ActionEvent e){
			Deposite d = new Deposite();
			d.deposite_amount();
		}
	}

    public static void main(String[] args) {
		MyBank m=new MyBank();
    }
}
