package Openaccountpack;

import com.mysql.cj.jdbc.Driver;

import java.sql.*;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;

import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Openaccount {
    // Database credentials
	Connection cn;
	Statement stmt;
	ResultSet rs;
	
	JFrame f;
	FlowLayout fl;
	JLabel l1;
	JLabel l2;
	JTextField tf1;
	JTextField tf2;
	JButton b;
	
	JLabel jp1;
	JLabel jp2;
	JLabel jp3;
	

    public void Open_account() {

        try {
			
			f=new JFrame("Open Account");
			f.setSize(600,800);
			fl=new FlowLayout();
			f.setLayout(fl);
			
            // Register JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");
			cn = DriverManager.getConnection("jdbc:mysql://localhost/practise","root","1234");
			stmt = cn.createStatement();

			
			l1=new JLabel("Enter your name:");
			tf1=new JTextField(10);
			l2=new JLabel("Enter Balance:");
			tf2=new JTextField(10);	
			b=new JButton("Open Account");
			
			f.add(l1);
			f.add(tf1);
			f.add(l2);
			f.add(tf2);
			f.add(b);
			
			jp1=new JLabel("");
			f.add(jp1);
			jp2=new JLabel("");
			f.add(jp2);
			jp3=new JLabel("");
			f.add(jp3);
			
			Myclass m1=new Myclass();
			b.addActionListener(m1);
			
			f.setVisible(true);
			
            rs.close();
            stmt.close();
            cn.close();
        } catch (SQLException e) {
            System.out.println(e);
		}catch(NullPointerException e){
			System.out.println(e);
        } catch (Exception e) {
            System.out.println(e);

        }

    }
	class Myclass implements ActionListener{
		public void actionPerformed(ActionEvent e){
			try{
				String sql = ("SELECT COUNT(*) as row_count FROM Bank");
				rs = stmt.executeQuery(sql);

				String ano=null;
				if (rs.next()) {
					int rowCount = rs.getInt("row_count");
					int rownext = rowCount + 1;
					if (rownext<10){
						String str = Integer.toString(rownext);
						ano = "A" + "0"+ str;
					}
					else{
						String str = Integer.toString(rownext);
						ano = "A" + str;
					}
				}
				String name=tf1.getText();
				String bal=tf2.getText();
				int balance=Integer.parseInt(bal);
				String query = "INSERT INTO Bank VALUES (?, ?, ?)";

				// Prepare the SQL statement with placeholders for the values
				PreparedStatement statement = cn.prepareStatement(query);
				statement.setString(1, ano);
				statement.setString(2, name);
				statement.setInt(3, balance);
				int rowsInserted = statement.executeUpdate();

				if (rowsInserted > 0) {
					jp1.setText("Your account has been opend successfully");
					jp2.setText("Your account number is " + ano + "...");

				} else {
					jp3.setText("Sorry..Insertion has failed");
				}
			}
			catch(Exception ex){
				
			}
		}
	}

}
